# Get an Key and Secret
# https://www.binance.com/restapipub.html

api_key = ''
api_secret = ''
recv_window = 5000

dingding_token = ""
